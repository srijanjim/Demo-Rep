package com.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.demo.dao.EmpDao;
import com.demo.model.Employee;

@Controller
public class EmployeeController {
	@Autowired
	EmpDao empDao;
	@RequestMapping("/employee")
	public String employee(Model model){
		List<Employee> emps = empDao.getAllEmployees();
		model.addAttribute("employees",emps);
		return "employees";
	}
	
	@RequestMapping(value="/addEmployee.do", method = RequestMethod.POST)
	public String addEmp(@ModelAttribute("employee") Employee emp){
		//System.out.println(emp.getName());
		empDao.saveEmployee(emp);
		return "redirect:/employee";
	}
	
	@RequestMapping(value="/search")
	public String search(Model model,@RequestParam("id") int id){
		List<Employee> emps = new ArrayList<Employee>();
		emps.add(empDao.getEmployee(id));
		model.addAttribute("employees",emps);
		return "employees";
	}
	
	@RequestMapping(value="/deleteEmployee/{id}")
	public String deleteEmployee(@PathVariable int id){
		empDao.deleteEmp(id);
		return "redirect:/employee";
	}
	
	
}
