package com.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.demo.dao.EmpDao;
import com.demo.model.Employee;

@Controller
public class HomeController {
	@Autowired
	EmpDao empDao;
	
	@RequestMapping("/")
	public String home(){
//		Employee emp = new Employee();
//        emp.setId(1);
//        emp.setDepartment_name("admin");
//        emp.setManager_name("Rinku Kumar");
//        emp.setName("Sagar Tripathi");
//        emp.setPosition("Software Engineer");
//        emp.setSalary(100);
//        empDao.saveEmployee(emp);
		return "redirect:/employee";
	}

	
}
