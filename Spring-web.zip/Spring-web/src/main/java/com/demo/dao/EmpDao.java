package com.demo.dao;

import java.util.List;

import com.demo.model.Employee;

public interface EmpDao {
	public void saveEmployee(Employee employee);
	public List<Employee> getAllEmployees();
	public void deleteEmp(int id);
	public Employee getEmployee(int id);
}
