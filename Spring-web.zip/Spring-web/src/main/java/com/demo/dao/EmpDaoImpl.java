package com.demo.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.demo.model.Employee;

@Repository
public class EmpDaoImpl implements EmpDao{
	
	@Autowired
	SessionFactory session;
	
	@Transactional
	public void saveEmployee(Employee employee){
		session.getCurrentSession().save(employee);
	}
	
	@Transactional
	public List<Employee> getAllEmployees(){
		return (List<Employee>)session.getCurrentSession().createQuery("from Employee").list();
	}

	@Transactional
	public Employee getEmployee(int id){
		return (Employee)session.getCurrentSession().get(Employee.class, id);
	}
	@Transactional
	public void deleteEmp(int id) {
		session.getCurrentSession().delete(getEmployee(id));
		
	}
}