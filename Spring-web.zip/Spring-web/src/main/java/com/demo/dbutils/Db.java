package com.demo.dbutils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Db {
	private static String URL = "jdbc:oracle:thin:@192.168.1.2:1521:load";
	private static String USER = "webapp";
	private static String PASS = "test";
	private static Connection  con;
	PreparedStatement pst;
	
	public static Connection getConnection(){
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(URL, USER, PASS);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return con;
	}
	public static void closeConnection(Connection con){
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		
	}
}
