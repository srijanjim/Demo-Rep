package com.utils.temp;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import com.demo.model.Employee;
public class HibernateTest {
	private static SessionFactory factory; 
	public static void main(String[] args) {
	      try{
	         factory = new AnnotationConfiguration().
	                   configure("hibernate.cfg.xml").
	                   //addPackage("com.xyz") //add package if used.
	                   addAnnotatedClass(Employee.class).
	                   buildSessionFactory();
	      }catch (Throwable ex) { 
	         System.err.println("Failed to create sessionFactory object." + ex);
	         throw new ExceptionInInitializerError(ex); 
	      }
	      Session session = factory.openSession();
	      Transaction tx = null;
	      Integer employeeID = null;
	      try{
	         tx = session.beginTransaction();
	         Employee emp = new Employee();
	         emp.setId(1);
	         emp.setDepartment_name("admin");
	         emp.setManager_name("Rinku Kumar");
	         emp.setName("Sagar Tripathi");
	         emp.setPosition("Software Engineer");
	         emp.setSalary(100);
	         employeeID = (Integer) session.save(emp); 
	         tx.commit();
	      }catch (HibernateException e) {
	         if (tx!=null) tx.rollback();
	         e.printStackTrace(); 
	      }finally {
	         session.close(); 
	      }
	}
}
