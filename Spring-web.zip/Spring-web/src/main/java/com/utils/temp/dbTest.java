package com.utils.temp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.demo.dbutils.Db;

public class dbTest {
	
	public static void main(String ar[]) throws SQLException{
		PreparedStatement pst;
		Connection con = Db.getConnection();
		
		
		try {
			con.prepareStatement("insert into employee(id,name,department_name, position, manager_name,salary) values(1,'sagar','sagar','sagar','sagar',10000)").execute();	
//			ResultSet rs = con.prepareStatement("select * from employee").executeQuery();
//			while(rs.next()){
//				System.out.println(rs.getInt("id")+" "+rs.getString("name")+" "+rs.getString("department_name"));
//			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			con.close();	
		}
	}

}
