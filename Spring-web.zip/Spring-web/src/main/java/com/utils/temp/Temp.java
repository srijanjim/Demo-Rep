package com.utils.temp;



public class Temp {
	public static void main(String ar[]){
		
	}
}
