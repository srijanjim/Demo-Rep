package net.webservicex.www;

import java.rmi.RemoteException;

import javax.xml.rpc.ServiceException;

public class TestGeoIP {

	public static void main(String[] args) {
		GeoIPServiceLocator gLoc = new GeoIPServiceLocator();
		try {
			System.out.println(gLoc.getGeoIPServiceSoap().getGeoIP("122.176.188.148").getCountryCode());
		} catch (RemoteException | ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
